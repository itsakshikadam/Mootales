package dbms;





import java.awt.EventQueue;



import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;



import javax.swing.JOptionPane;



import java.awt.Font;

import javax.swing.SwingConstants;

import javax.swing.JTextArea;

import javax.swing.JPasswordField;

import javax.swing.JButton;

import java.awt.Color;

import java.awt.event.ActionListener;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.awt.event.ActionEvent;



public class Admin extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;

	private JPasswordField passwordField;
    Connection connection;


	/**

	 * Launch the application.

	 */

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {

			public void run() {

				try {

					Admin frame = new Admin();

					frame.setVisible(true);

				} catch (Exception e) {

					e.printStackTrace();

				}

			}

		});

	}



	/**

	 * Create the frame.

	 */

	public Admin() {
		try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
        } catch (ClassNotFoundException | SQLException e1) {
            e1.printStackTrace();
        }

		setResizable(false);

		setTitle("ADMIN");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 864, 709);

		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		contentPane.setLayout(null);

		

		JLabel lblNewLabel_1 = new JLabel("USERID");

		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		lblNewLabel_1.setBounds(359, 265, 130, 47);

		contentPane.add(lblNewLabel_1);

		

		final JTextArea textArea = new JTextArea();

		textArea.setFont(new Font("Serif", Font.BOLD, 18));

		textArea.setBounds(543, 265, 253, 37);

		contentPane.add(textArea);

		

		JLabel lblNewLabel_2 = new JLabel("PASSWORD");

		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		lblNewLabel_2.setBounds(359, 354, 145, 30);

		contentPane.add(lblNewLabel_2);

		

		passwordField = new JPasswordField();

		passwordField.setBounds(543, 355, 253, 37);

		contentPane.add(passwordField);

		

		JButton btnNewButton = new JButton("LOGIN");

btnNewButton.addActionListener(new ActionListener() {

			

			public void actionPerformed(ActionEvent e) {

				

			    String password = new String(passwordField.getPassword());

			    String usernameStr = textArea.getText().trim();

			 // Check if the username and password fields are empty
			 if (usernameStr.isEmpty() || password.isEmpty()) {
			     JOptionPane.showMessageDialog(null, "Please enter all information.");
			     return; // Exit the method if any field is empty
			 }

			 int username = Integer.parseInt(usernameStr);

			    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26")) {

			        String query = "SELECT * FROM admin WHERE Admin_ID = ? AND Password = ?";

			        try (PreparedStatement pstmt = connection.prepareStatement(query)) {

			            pstmt.setInt(1, username);

			            pstmt.setString(2, password);

			            ResultSet resultSet = pstmt.executeQuery();



			            if (resultSet.next()) {

			                JOptionPane.showMessageDialog(null, "Login successful");

			                Admin_Crud ad=new Admin_Crud();

							ad.setVisible(true);


			            } else {

			                JOptionPane.showMessageDialog(null, "Username or password wrong...");

			                textArea.setText("");

			                passwordField.setText("");

			            }

			        }

			    } catch (SQLException ex) {

			        ex.printStackTrace();

			        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());

			    }

			}

		});

		btnNewButton.setForeground(new Color(245, 255, 250));

		btnNewButton.setBackground(new Color(0, 128, 128));

		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 23));

		btnNewButton.setBounds(359, 431, 145, 47);

		contentPane.add(btnNewButton);

		

		JPanel panel = new JPanel();

		panel.setBackground(new Color(0, 128, 128));

		panel.setBounds(0, 10, 315, 652);

		contentPane.add(panel);

		panel.setLayout(null);

		

		JLabel lblNewLabel = new JLabel("WELCOME");

		lblNewLabel.setBounds(45, 263, 245, 86);

		panel.add(lblNewLabel);

		lblNewLabel.setFont(new Font("Stencil", Font.BOLD, 40));

		JButton btnNewButton_2 = new JButton("Back");

		btnNewButton_2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				project pr=new project();

				pr.setVisible(true);

			}

		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 15));

		btnNewButton_2.setBounds(10, 10, 76, 21);

		panel.add(btnNewButton_2);
		

		JLabel lblNewLabel_3 = new JLabel("ADMIN LOGIN ");

		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 35));

		lblNewLabel_3.setBounds(423, 127, 280, 37);

		contentPane.add(lblNewLabel_3);

		

		JLabel lblNewLabel_4 = new JLabel("Create your account");

		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));

		lblNewLabel_4.setBounds(359, 527, 178, 30);

		contentPane.add(lblNewLabel_4);

		

		JButton btnNewButton_1 = new JButton("SIGN UP");

		btnNewButton_1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				Admin_signUp ad=new Admin_signUp();

				ad.setVisible(true);

			}

		});

		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));

		btnNewButton_1.setBounds(583, 524, 130, 37);

		contentPane.add(btnNewButton_1);

	}

}

