package dbms;
import java.awt.EventQueue;

import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;

import javax.swing.JOptionPane;

import javax.swing.JTextField;

import javax.swing.JPasswordField;

import javax.swing.JButton;

import java.awt.Font;

import java.awt.event.ActionListener;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.SQLException;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;

import java.sql.ResultSet;

import java.sql.Statement;

import java.awt.Color;



public class Admin_signUp extends JFrame {

    private JPanel contentPane;

    private JTextField adminIdField;

    private JTextField nameField;

    private JTextField emailField;

    private JPasswordField passwordField;

    private JTextField roleField;



    // JDBC connection parameters

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";

    static final String DB_URL = "jdbc:mysql://localhost/dbms";

    static final String USER = "root";

    static final String PASS = "root26";



    // Method to validate Gmail address

    private boolean isValidGmail(String email) {

        // Regular expression for Gmail address validation

        String gmailRegex = "^[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)*@gmail\\.com$";

        Pattern pattern = Pattern.compile(gmailRegex);

        Matcher matcher = pattern.matcher(email);

        return matcher.matches();

    }



    // Method to insert data into the admin table

    private void insertAdminData(String adminId, String name, String email, String password, String role) {

        if (!isValidGmail(email)) {

            JOptionPane.showMessageDialog(this, "Please enter a valid Gmail address.");

            return;

        }



        Connection conn = null;

        PreparedStatement pstmt = null;



        try {

            // Register JDBC driver

            Class.forName(JDBC_DRIVER);



            // Open a connection

            conn = DriverManager.getConnection(DB_URL, USER, PASS);



            // SQL query to insert data

            String sql = "INSERT INTO admin (admin_id, username, password, email, role) VALUES (?, ?, ?, ?, ?)";



            // Create a prepared statement

            pstmt = conn.prepareStatement(sql);



            // Set parameters for the statement

            pstmt.setString(1, adminId);

            pstmt.setString(2, name);

            pstmt.setString(3, password);

            pstmt.setString(4, email);

            pstmt.setString(5, role);



            // Execute the update

            pstmt.executeUpdate();



            // Inform the user about successful signup

            JOptionPane.showMessageDialog(this, "Admin signed up successfully!");



        } catch (SQLException se) {

            // Handle errors for JDBC

            se.printStackTrace();

        } catch (Exception e) {

            // Handle errors for Class.forName

            e.printStackTrace();

        } finally {

            // Close resources

            try {

                if (pstmt != null) pstmt.close();

                if (conn != null) conn.close();

            } catch (SQLException se) {

                se.printStackTrace();

            }

        }

    }



    /**

     * Create the frame.

     */

    public Admin_signUp() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setBounds(100, 100, 845, 660);

        contentPane = new JPanel();

        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);

        contentPane.setLayout(null);



        JLabel lblAdminSignUp = new JLabel("Admin Sign Up");

        lblAdminSignUp.setFont(new Font("Tahoma", Font.BOLD, 35));

        lblAdminSignUp.setBounds(425, 47, 273, 63);

        contentPane.add(lblAdminSignUp);



        JLabel lblAdminId = new JLabel("Admin ID:");

        lblAdminId.setFont(new Font("Tahoma", Font.BOLD, 17));

        lblAdminId.setBounds(410, 155, 100, 20);

        contentPane.add(lblAdminId);



        adminIdField = new JTextField();

        adminIdField.setBounds(410, 185, 200, 25);

        contentPane.add(adminIdField);

        adminIdField.setColumns(10);



        JLabel lblName = new JLabel("Name:");

        lblName.setFont(new Font("Tahoma", Font.BOLD, 17));

        lblName.setBounds(410, 236, 100, 20);

        contentPane.add(lblName);



        nameField = new JTextField();

        nameField.setBounds(410, 266, 200, 25);

        contentPane.add(nameField);

        nameField.setColumns(10);



        JLabel lblEmail = new JLabel("Email:");

        lblEmail.setFont(new Font("Tahoma", Font.BOLD, 17));

        lblEmail.setBounds(410, 322, 100, 20);

        contentPane.add(lblEmail);



        emailField = new JTextField();

        emailField.setBounds(410, 352, 200, 25);

        contentPane.add(emailField);

        emailField.setColumns(10);



        JLabel lblPassword = new JLabel("Password:");

        lblPassword.setFont(new Font("Tahoma", Font.BOLD, 17));

        lblPassword.setBounds(410, 409, 100, 20);

        contentPane.add(lblPassword);



        passwordField = new JPasswordField();

        passwordField.setBounds(410, 439, 200, 25);

        contentPane.add(passwordField);



        JLabel lblRole = new JLabel("Role:");

        lblRole.setFont(new Font("Tahoma", Font.BOLD, 17));

        lblRole.setBounds(410, 491, 100, 20);

        contentPane.add(lblRole);



        roleField = new JTextField();

        roleField.setBounds(410, 521, 200, 25);

        contentPane.add(roleField);

        roleField.setColumns(10);



        JButton btnSignUp = new JButton("Sign Up");

        btnSignUp.setFont(new Font("Tahoma", Font.BOLD, 20));

        btnSignUp.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String adminId = adminIdField.getText();

                String name = nameField.getText();

                String email = emailField.getText();              

                String password = new String(passwordField.getPassword());          

                String role = roleField.getText();



                // Insert data into the admin table

                if(isValidGmail(email)) {

                

                Admin_Crud ad=new Admin_Crud();

                ad.setVisible(true)

                ;

            }

            else {

            	insertAdminData(adminId, name, email, password, role);

            }

            }

        });

        btnSignUp.setBounds(609, 570, 147, 46);

        contentPane.add(btnSignUp);

        

        JPanel panel = new JPanel();

        panel.setBackground(new Color(0, 128, 128));

        panel.setBounds(0, 10, 333, 679);

        contentPane.add(panel);

        panel.setLayout(null);

        

        JLabel lblNewLabel = new JLabel("Welcome");

        lblNewLabel.setFont(new Font("Calisto MT", Font.BOLD, 50));

        lblNewLabel.setBounds(26, 268, 254, 107);

        panel.add(lblNewLabel);

    }



    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {

            public void run() {

                try {

                    Admin_signUp frame = new Admin_signUp();

                    frame.setVisible(true);

                } catch (Exception e) {

                    e.printStackTrace();

                }

            }

        });

    }

}

