package dbms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.TextArea;

import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class receipt extends JFrame {
private static final long serialVersionUID = 1L;
private JPanel contentPane;
Connection connection;
/**
* Launch the application.
*/
public static void main(String[] args) {
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
receipt frame = new receipt();
frame.setVisible(true);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}

/**
* Create the frame.
*/
public receipt() {
	try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
    } catch (ClassNotFoundException | SQLException e1) {
        JOptionPane.showMessageDialog(null, "Failed to connect to the database.");
        e1.printStackTrace();
    }
	
setResizable(false);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setBounds(100, 100, 894, 693);
contentPane = new JPanel();
contentPane.setBackground(new Color(240, 255, 240));
contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
setContentPane(contentPane);
contentPane.setLayout(null);

JLabel lblNewLabel = new JLabel("MooTales");
lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
lblNewLabel.setBounds(290, 36, 283, 76);
contentPane.add(lblNewLabel);

JLabel lblNewLabel_1 = new JLabel("Experience the pure Delite....");
lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 20));
lblNewLabel_1.setBounds(267, 108, 318, 25);
contentPane.add(lblNewLabel_1);

JLabel lblNewLabel_2 = new JLabel("Quantity");
lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_2.setBounds(254, 323, 104, 31);
contentPane.add(lblNewLabel_2);

JLabel lblNewLabel_3 = new JLabel("Product");
lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_3.setBounds(440, 326, 85, 25);
contentPane.add(lblNewLabel_3);



JLabel lblNewLabel_4 = new JLabel("Total Price");
lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_4.setBounds(226, 437, 132, 31);
contentPane.add(lblNewLabel_4);

JLabel lblNewLabel_5 = new JLabel("*****CUSTOMER COPY *****");
lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 23));
lblNewLabel_5.setBounds(234, 613, 448, 33);
contentPane.add(lblNewLabel_5);

JLabel lblNewLabel_6 = new JLabel("Customer ID ");
lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_6.setBounds(69, 205, 147, 21);
contentPane.add(lblNewLabel_6);

JLabel lblNewLabel_7 = new JLabel("Customer Name");
lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_7.setBounds(340, 203, 167, 25);
contentPane.add(lblNewLabel_7);

JLabel lblNewLabel_8 = new JLabel("Product ID");
lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_8.setBounds(69, 332, 117, 22);
contentPane.add(lblNewLabel_8);

JLabel lblNewLabel_9 = new JLabel("ProductRate");
lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 20));
lblNewLabel_9.setBounds(612, 326, 143, 25);
contentPane.add(lblNewLabel_9);

JTextArea textArea = new JTextArea();
textArea.setBounds(69, 238, 117, 22);
contentPane.add(textArea);

JTextArea textArea_1 = new JTextArea();
textArea_1.setBounds(341, 238, 196, 22);
contentPane.add(textArea_1);

JTextArea textArea_2 = new JTextArea();
textArea_2.setBounds(69, 364, 104, 22);
contentPane.add(textArea_2);

JTextArea textArea_3 = new JTextArea();
textArea_3.setBounds(254, 364, 92, 22);
contentPane.add(textArea_3);


JTextArea textArea_4 = new JTextArea();
textArea_4.setBounds(440, 361, 97, 31);
contentPane.add(textArea_4);

JTextArea textArea_5 = new JTextArea();
textArea_5.setBounds(612, 364, 104, 22);
contentPane.add(textArea_5);

JTextArea textArea_6 = new JTextArea();
textArea_6.setBounds(368, 444, 139, 24);
contentPane.add(textArea_6);

JButton btnNewButton = new JButton("GENERATE");
btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
btnNewButton.setBounds(505, 523, 146, 44);
btnNewButton.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        try {
            PreparedStatement ps6 = connection.prepareStatement("Select Cust_id, Product_Id, quantity, Total_price from orders order by Order_id DESC LIMIT 1");
            ResultSet rs6 = ps6.executeQuery();
            if (rs6.next()) {
                String custid = Integer.toString(rs6.getInt("Cust_id"));
                int pid = rs6.getInt("Product_Id");
                int quantity2 = rs6.getInt("quantity");
                String total_price2 = rs6.getString("Total_price");

                PreparedStatement ps8 = connection.prepareStatement("Select CustomerName from customers where cust_Id = ?");
                ps8.setString(1, custid);
                ResultSet rs8 = ps8.executeQuery();
                if (rs8.next()) {
                    String custName2 = rs8.getString("CustomerName");

                    PreparedStatement ps9 = connection.prepareStatement("Select ProductName from product where productId = ?");
                    ps9.setInt(1, pid);
                    ResultSet rs9 = ps9.executeQuery();
                    if (rs9.next()) {
                        String productName2 = rs9.getString("ProductName");


                        PreparedStatement ps10 = connection.prepareStatement("Select Price from product where productId = ?");
                        ps10.setInt(1, pid);
                        ResultSet rs10 = ps10.executeQuery();
                        if (rs10.next()) {
                            int rate = rs10.getInt("Price");
                        
                        textArea.setText(custid);
                        textArea_1.setText(custName2);
                        textArea_2.setText(Integer.toString(pid));
                        textArea_3.setText(productName2);
                        textArea_4.setText(Integer.toString(quantity2));
                        textArea_5.setText(Integer.toString(rate));
                        textArea_6.setText(total_price2);
                    }
                }
            }
        }} catch(Exception e4) {
            e4.printStackTrace();
        }
    }
});


contentPane.add(btnNewButton);

JButton btnNewButton_1 = new JButton("BACK");
btnNewButton_1.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
Order or=new Order();
or.setVisible(true);
}
});
btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
btnNewButton_1.setBounds(164, 523, 139, 44);
contentPane.add(btnNewButton_1);
}
}
