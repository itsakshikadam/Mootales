package dbms;
import java.awt.EventQueue;



import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;

import javax.swing.JOptionPane;



import java.awt.Font;

import javax.swing.SwingConstants;

import javax.swing.JTextArea;

import javax.swing.JPasswordField;

import javax.swing.JButton;

import java.awt.Color;

import java.awt.event.ActionListener;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

import java.awt.event.ActionEvent;



public class Signup extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private JPasswordField passwordField;

    private Connection connection; // Declare connection variable

    private JLabel lblUserId; // To display the generated user ID



    // Launch the application.

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {

            public void run() {

                try {

                    Signup frame = new Signup();

                    frame.setVisible(true);

                } catch (Exception e) {

                    e.printStackTrace();

                }

            }

        });

    }



    // Create the frame.

    public Signup() {

        setResizable(false);

        // Initialize connection

        try {

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");

        } catch (SQLException e1) {

            e1.printStackTrace();

        }



        setTitle("SignUp Page");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setBounds(100, 100, 860, 660);

        contentPane = new JPanel();

        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);

        contentPane.setLayout(null);



        JLabel lblNewLabel = new JLabel("Name");

        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        lblNewLabel.setBounds(316, 136, 104, 32);

        contentPane.add(lblNewLabel);



        final JTextArea textArea = new JTextArea();

        textArea.setBounds(316, 178, 325, 32);

        contentPane.add(textArea);



        JLabel lblNewLabel_1 = new JLabel("PHONE NO.");

        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        lblNewLabel_1.setBounds(314, 220, 122, 24);

        contentPane.add(lblNewLabel_1);



        JLabel lblNewLabel_2 = new JLabel("Sign Up");

        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));

        lblNewLabel_2.setBounds(388, 23, 195, 82);

        contentPane.add(lblNewLabel_2);



        final JTextArea textArea_1 = new JTextArea();

        textArea_1.setBounds(316, 254, 325, 32);

        contentPane.add(textArea_1);



        JLabel lblNewLabel_3 = new JLabel("Password");

        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        lblNewLabel_3.setBounds(316, 390, 104, 24);

        contentPane.add(lblNewLabel_3);



        passwordField = new JPasswordField();

        passwordField.setBounds(316, 435, 305, 38);

        contentPane.add(passwordField);



        JLabel lblNewLabel_4 = new JLabel("EMAIL ");

        lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        lblNewLabel_4.setBounds(316, 313, 104, 24);

        contentPane.add(lblNewLabel_4);



        final JTextArea textArea_2 = new JTextArea();

        textArea_2.setBounds(316, 345, 305, 32);

        contentPane.add(textArea_2);



        JButton btnNewButton = new JButton("PROCEED");

        btnNewButton.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                String username = textArea.getText(); // Retrieving username from JTextArea

                String email = textArea_2.getText(); // Retrieving email from JTextArea

                String user_cont_str = textArea_1.getText(); // Retrieving contact number from JTextArea

                String user_pass = new String(passwordField.getPassword()); // Retrieving password from JPasswordField



                // Validating email

                if (!isValidEmail(email)) {

                    JOptionPane.showMessageDialog(null, "Invalid Email Address");

                    return;

                }



                // Validating phone number

                if (!isValidPhoneNumber(user_cont_str)) {

                    JOptionPane.showMessageDialog(null, "Invalid Phone Number");

                    return;

                }



                double user_cont = Double.parseDouble(user_cont_str); // Parsing phone number as a double



                try (Statement stmt = connection.createStatement()) {

                    String query = "INSERT INTO customers(CustomerName, Email, Ph_no, Password) VALUES (?, ?, ?, ?)";

                    try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

                        pstmt.setString(1, username);

                        pstmt.setString(2, email);

                        pstmt.setDouble(3, user_cont);

                        pstmt.setString(4, user_pass);

                        pstmt.executeUpdate();



                        // Retrieve the generated user ID

                        ResultSet generatedKeys = pstmt.getGeneratedKeys();

                        if (generatedKeys.next()) {

                            int userId = generatedKeys.getInt(1);

                            lblUserId.setText("Sign-In Successful!! Your UserID is: " + userId); // Display the generated user ID

                            JOptionPane.showMessageDialog(null, "Sign-Up Successful!! Your UserID is: " + userId);

                        } else {

                            JOptionPane.showMessageDialog(null, "Failed to retrieve UserID.");

                        }

                    } catch (SQLException e1) {

                        e1.printStackTrace();

                        JOptionPane.showMessageDialog(null, "Sign-Up Failed. Please try again.");

                    }

                } catch (SQLException e2) {

                    e2.printStackTrace();

                    JOptionPane.showMessageDialog(null, "Sign-Up Failed. Please try again.");

                }

                CustomerPage cs=new CustomerPage();

                cs.setVisible(true);

            }

        });

        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 25));

        btnNewButton.setBounds(436, 540, 168, 38);

        contentPane.add(btnNewButton);



        lblUserId = new JLabel(); // Initialize lblUserId

        lblUserId.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        lblUserId.setBounds(316, 540, 450, 24);

        contentPane.add(lblUserId);



        JPanel panel = new JPanel();

        panel.setBackground(new Color(0, 128, 128));

        panel.setBounds(10, 10, 278, 621);

        contentPane.add(panel);

        panel.setLayout(null);

        

        JLabel lblNewLabel_5 = new JLabel("WELCOME");

        lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 70));

        lblNewLabel_5.setBounds(97, 222, 45, 13);

        panel.add(lblNewLabel_5);

        

        JLabel lblNewLabel_6 = new JLabel("WELCOME");

        lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 50));

        lblNewLabel_6.setBounds(0, 204, 278, 162);

        panel.add(lblNewLabel_6);

    }



    // Method to validate email

    private boolean isValidEmail(String email) {

        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";

        Pattern pattern = Pattern.compile(emailRegex);

        Matcher matcher = pattern.matcher(email);

        return matcher.matches();

    }



    // Method to validate phone number

    private boolean isValidPhoneNumber(String phone) {

        // Phone number must be exactly 10 digits long

        return phone.matches("\\d{10}");

    }

}