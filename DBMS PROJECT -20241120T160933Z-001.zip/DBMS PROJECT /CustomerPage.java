package dbms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.cj.jdbc.CallableStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    Connection connection;

    // Launch the application.
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    CustomerPage frame = new CustomerPage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Create the frame.
    public CustomerPage() {
        try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
        } catch (ClassNotFoundException | SQLException e1) {
            e1.printStackTrace();
        }

        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 885, 673);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 128, 128));
        panel.setBounds(554, 0, 317, 669);
        contentPane.add(panel);
        panel.setLayout(null);

        JTextArea textArea_1 = new JTextArea();
        textArea_1.setBounds(54, 337, 158, 22);
        panel.add(textArea_1);

        JLabel lblNewLabel_3 = new JLabel("Order ID");
        lblNewLabel_3.setBounds(54, 309, 110, 18);
        panel.add(lblNewLabel_3);
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));

        JTextArea textArea = new JTextArea();
        textArea.setBounds(54, 239, 158, 22);
        panel.add(textArea);

        JLabel lblNewLabel_2 = new JLabel("Customer ID ");
        lblNewLabel_2.setBounds(54, 203, 178, 26);
        panel.add(lblNewLabel_2);
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));

        JLabel lblNewLabel_1 = new JLabel("CANCEL ORDER");
        lblNewLabel_1.setBounds(34, 121, 283, 53);
        panel.add(lblNewLabel_1);
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(0, 128, 128));
        panel_1.setBounds(0, 404, 544, 242);
        contentPane.add(panel_1);
        panel_1.setLayout(null);

        JButton btnNewButton_1 = new JButton("CANCEL");
        btnNewButton_1.setBounds(197, 432, 110, 26);
        panel.add(btnNewButton_1);

        btnNewButton_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate input before parsing
                    String cidText = textArea.getText().trim();
                    String odidText = textArea_1.getText().trim();

                    if (cidText.isEmpty() || odidText.isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Please enter both Customer ID and Order ID.");
                        return; // Exit the method without further processing
                    }

                    // Parse the validated input into integers
                    int cid = Integer.parseInt(cidText);
                    int odid = Integer.parseInt(odidText);

                    try (CallableStatement cstmt = (CallableStatement) connection.prepareCall("{CALL CheckCustomerAndOrder(?, ?)}")) {
                        cstmt.setInt(1, cid);
                        cstmt.setInt(2, odid);
                        ResultSet rs = cstmt.executeQuery();
                        
                        if (rs.next()) {
                            int custExists = rs.getInt("CustomerExists");
                            int orderExists = rs.getInt("OrderExists");
                            
                            if (custExists > 0 && orderExists > 0) {
                                // Both customer and order exist, proceed with the delete query
                                // Execute the delete query here
                            } else {
                                JOptionPane.showMessageDialog(null, "Customer or order does not exist.");
                            }
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                 
                   // Prepare SQL statement to delete the order
                    String query1 = "Update orders SET status='canceled' where Order_ID = ?";
                    PreparedStatement pstmt1 = connection.prepareStatement(query1);
                   
                    pstmt1.setInt(1, odid);
                    
                    
                    // Prepare SQL statement to delete the order
                    String query = "DELETE FROM orders WHERE Cust_ID = ? AND Order_ID = ?";
                    PreparedStatement pstmt = connection.prepareStatement(query);
                    pstmt.setInt(1, cid);
                    pstmt.setInt(2, odid);

                    // Execute the deletion query
                    int rowsAffected = pstmt.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Order cancelled successfully");
                    } else {
                        JOptionPane.showMessageDialog(null,
                                "No order found for the given Customer ID and Order ID.");
                    }

                    // Close resources
                    pstmt.close();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "Please enter valid integer values for Customer ID and Order ID.");
                    ex.printStackTrace();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null,
                            "An error occurred while processing the request. Please try again later.");
                    ex.printStackTrace();
                }
            }
        });

        btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 18));

        JButton btnNewButton = new JButton("CLICK ");
        btnNewButton.setBounds(135, 80, 124, 41);
        panel_1.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Order or = new Order();
                or.setVisible(true);
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

        JLabel lblNewLabel = new JLabel("PLACE YOUR ORDER HERE ");
        lblNewLabel.setBounds(50, 22, 298, 48);
        panel_1.add(lblNewLabel);
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));

        JButton btnNewButton_2 = new JButton("Log Out");
        btnNewButton_2.setBounds(340, 161, 145, 48);
        panel_1.add(btnNewButton_2);
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Login ln = new Login();
                ln.setVisible(true);
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
   
        JLabel lblNewLabel_4 = new JLabel("Valuable Customers ");

        lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));

        lblNewLabel_4.setBounds(0, 10, 281, 49);

        contentPane.add(lblNewLabel_4);

        

        JLabel lblNewLabel_5 = new JLabel("Samantha H.:");

        lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 15));

        lblNewLabel_5.setBounds(10, 103, 114, 29);

        contentPane.add(lblNewLabel_5);

        

        JLabel lblNewLabel_6 = new JLabel("\"I'm blown away by the seamless");

        lblNewLabel_6.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_6.setBounds(10, 131, 239, 19);

        contentPane.add(lblNewLabel_6);

        

        JLabel lblNewLabel_7 = new JLabel("ordering process on MooTales\"");

        lblNewLabel_7.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_7.setBounds(10, 152, 220, 19);

        contentPane.add(lblNewLabel_7);



        ImageIcon imageIcon = new ImageIcon("path/to/your/image.jpg"); // Change path to your image file

        String image = null;

       	ImageIcon imageScaled = new ImageIcon(image);

        

        JLabel lblNewLabel_8 = new JLabel("FEEDBACK");

        lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));

        lblNewLabel_8.setBounds(10, 54, 169, 32);

        contentPane.add(lblNewLabel_8);

        

        JLabel lblNewLabel_9 = new JLabel("New label");

        lblNewLabel_9.setIcon(new ImageIcon("C:\\Users\\SRUSHTI JAMBHALE\\Downloads\\milk2.png"));

        lblNewLabel_9.setBounds(259, -28, 293, 494);

        contentPane.add(lblNewLabel_9);

        

        JLabel lblNewLabel_10 = new JLabel("From selecting my favorite dairy");

        lblNewLabel_10.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_10.setBounds(10, 231, 225, 19);

        contentPane.add(lblNewLabel_10);

        

        JLabel lblNewLabel_11 = new JLabel("Michael S.:");

        lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 15));

        lblNewLabel_11.setBounds(10, 208, 125, 19);

        contentPane.add(lblNewLabel_11);

        

        JLabel lblNewLabel_12 = new JLabel("product to choosing the delivery ");

        lblNewLabel_12.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_12.setBounds(10, 254, 239, 19);

        contentPane.add(lblNewLabel_12);

        

        JLabel lblNewLabel_13 = new JLabel("time, everything was smooth ");

        lblNewLabel_13.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_13.setBounds(10, 272, 239, 19);

        contentPane.add(lblNewLabel_13);

        

        JLabel lblNewLabel_14 = new JLabel("sailing.\"");

        lblNewLabel_14.setFont(new Font("Tahoma", Font.ITALIC, 15));

        lblNewLabel_14.setBounds(10, 295, 68, 19);

        contentPane.add(lblNewLabel_14);


    
    }
}
