package dbms;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Order extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private Connection connection;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Order frame = new Order();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Order() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
        } catch (ClassNotFoundException | SQLException e1) {
            JOptionPane.showMessageDialog(null, "Failed to connect to the database.");
            e1.printStackTrace();
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 858, 651);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("PLACE ORDER HERE");
        lblNewLabel.setBackground(new Color(0, 128, 128));
        lblNewLabel.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
        lblNewLabel.setBounds(403, 58, 297, 47);
        contentPane.add(lblNewLabel);

        JButton btnNewButton_5 = new JButton("Check Stock ");
        btnNewButton_5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayProductTable();
            }
        });
        btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnNewButton_5.setBounds(490, 561, 176, 32);
        contentPane.add(btnNewButton_5);

        JLabel lblNewLabel_1 = new JLabel("Customer ID");
        lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_1.setBounds(345, 138, 148, 25);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Product ID");
        lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_2.setBounds(345, 207, 127, 25);
        contentPane.add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("Quantity");
        lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblNewLabel_3.setBounds(345, 270, 134, 25);
        contentPane.add(lblNewLabel_3);

        JTextArea textArea = new JTextArea();
        textArea.setBounds(509, 142, 127, 22);
        contentPane.add(textArea);

        JTextArea textArea_1 = new JTextArea();
        textArea_1.setBounds(509, 210, 127, 22);
        contentPane.add(textArea_1);

        JTextArea textArea_2 = new JTextArea();
        textArea_2.setBounds(509, 274, 127, 22);
        contentPane.add(textArea_2);

        JButton btnNewButton_4 = new JButton("Confirm ");
        btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
        btnNewButton_4.setBounds(613, 326, 127, 32);
        btnNewButton_4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Validate input
                String customerIdStr = textArea.getText().trim();
                String productIdStr = textArea_1.getText().trim();
                String quantityStr = textArea_2.getText().trim();

                if (customerIdStr.isEmpty() || productIdStr.isEmpty() || quantityStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter all values (Customer ID, Product ID, Quantity) before placing the order.");
                    return; // Exit the method if any field is empty
                }

                try {
                    int customerId = Integer.parseInt(customerIdStr);
                    int productId = Integer.parseInt(productIdStr);
                    int quantity = Integer.parseInt(quantityStr);

                    // Check quantity availability
                    int availableQuantity = checkQuantityAvailability(productId);
                    if (availableQuantity < quantity) {
                        JOptionPane.showMessageDialog(null, "Not enough quantity available in stock.");
                        return;
                    }

                    // Fetch price of the selected product
                    double price = 0.0;
                    try (PreparedStatement priceStmt = connection.prepareStatement("SELECT price FROM product WHERE ProductID = ?")) {
                        priceStmt.setInt(1, productId);
                        ResultSet priceResult = priceStmt.executeQuery();
                        if (priceResult.next()) {
                            price = priceResult.getDouble("price");
                        } else {
                            JOptionPane.showMessageDialog(null, "Product not found.");
                            return; // Exit the method if product not found
                        }
                    }

                    // Calculate total price
                    double totalPrice = price * quantity;

                    // Get current date and time as order date
                    Timestamp orderDate = new Timestamp(System.currentTimeMillis());

                    String status = "placed";

                    try (PreparedStatement insertStmt = connection.prepareStatement("INSERT INTO orders (Cust_ID, Product_ID, Quantity, Order_Date, Total_Price, Status) VALUES (?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                        insertStmt.setInt(1, customerId);
                        insertStmt.setInt(2, productId);
                        insertStmt.setInt(3, quantity);
                        insertStmt.setTimestamp(4, orderDate);
                        insertStmt.setDouble(5, totalPrice);
                        insertStmt.setString(6, status);

                        int rowsAffected = insertStmt.executeUpdate();

                        if (rowsAffected > 0) {
                            // Get the last inserted order_id
                            int orderId = 0;
                            try (ResultSet generatedKeys = insertStmt.getGeneratedKeys()) {
                                if (generatedKeys.next()) {
                                    orderId = generatedKeys.getInt(1);
                                } else {
                                    JOptionPane.showMessageDialog(null, "Failed to retrieve order ID.");
                                    return;
                                }
                            }
                            
                            // Update product quantity
                            updateProductQuantity(productId, availableQuantity - quantity);
                            
                            // Display order success message with order_id
                            JOptionPane.showMessageDialog(null, "Order placed successfully! Order ID: " + orderId);
                        } else {
                            JOptionPane.showMessageDialog(null, "Failed to place order.");
                        }
                    }

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter valid integer values for Customer ID, Product ID, and Quantity.");
                    ex.printStackTrace();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred while processing the request.");
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(btnNewButton_4);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 128, 128));
        panel.setBounds(10, 10, 297, 604);
        contentPane.add(panel);
        panel.setLayout(null);

        JButton btnNewButton_2 = new JButton("Back To Menu");
        btnNewButton_2.setBounds(39, 391, 207, 47);
        panel.add(btnNewButton_2);
        btnNewButton_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CustomerPage cm = new CustomerPage();
                cm.setVisible(true);
            }
        });
        btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));

        JButton btnNewButton = new JButton("Generate Receipt");
        btnNewButton.setBounds(39, 218, 207, 47);
        panel.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                receipt rt = new receipt();
                rt.setVisible(true);
            }
        });
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(330, 398, 504, 153);
        contentPane.add(scrollPane);

        table = new JTable();
        scrollPane.setViewportView(table);

        // Method to display the Customer table
        displayProductTable();
    }

    private int checkQuantityAvailability(int productId) {
        int availableQuantity = 0;
        try (PreparedStatement quantityStmt = connection.prepareStatement("SELECT QuantityAvailable FROM product WHERE ProductID = ?")) {
            quantityStmt.setInt(1, productId);
            ResultSet quantityResult = quantityStmt.executeQuery();
            if (quantityResult.next()) {
                availableQuantity = quantityResult.getInt("QuantityAvailable");
            } else {
                JOptionPane.showMessageDialog(null, "Product not found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while checking product quantity.");
            ex.printStackTrace();
        }
        return availableQuantity;
    }

    private void updateProductQuantity(int productId, int newQuantity) {
        try (PreparedStatement updateStmt = connection.prepareStatement("UPDATE product SET QuantityAvailable = ? WHERE ProductID = ?")) {
            updateStmt.setInt(1, newQuantity);
            updateStmt.setInt(2, productId);
            updateStmt.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while updating product quantity.");
            ex.printStackTrace();
        }
    }

    private void displayProductTable() {
        String url = "jdbc:mysql://localhost:3306/dbms";
        String user = "root";
        String password = "root26";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Product");
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            DefaultTableModel model = new DefaultTableModel();

            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = resultSet.getObject(i);
                }
                model.addRow(row);
            }

            table.setModel(model);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Failed to fetch product data.");
            ex.printStackTrace();
        }
    }

}
