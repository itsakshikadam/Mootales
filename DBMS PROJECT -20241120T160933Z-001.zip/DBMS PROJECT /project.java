package dbms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class project extends JFrame {
private static final long serialVersionUID = 1L;
private JPanel contentPane;

/**
* Launch the application.
*/
public static void main(String[] args) {
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
project frame = new project();
frame.setVisible(true);
} catch (Exception e) {
e.printStackTrace();
}
}
});
}

/**
* Create the frame.
*/
public project() {
setResizable(false);
setTitle("D Dairy");
setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
setBounds(100, 100, 921, 720);
contentPane = new JPanel();
contentPane.setBackground(new Color(224, 255, 255));
contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
setContentPane(contentPane);
contentPane.setLayout(null);

JLabel lblNewLabel = new JLabel("MooTales");
lblNewLabel.setBounds(389, 4, 382, 141);
lblNewLabel.setBackground(new Color(0, 0, 139));
lblNewLabel.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 70));
contentPane.add(lblNewLabel);

JPanel panel = new JPanel();
panel.setBackground(new Color(47, 79, 79));
panel.setBounds(0, 0, 305, 736);
contentPane.add(panel);
panel.setLayout(null);

JButton btnNewButton = new JButton("Admin");
btnNewButton.setBounds(54, 347, 153, 79);
panel.add(btnNewButton);
btnNewButton.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent e) {
Admin ad=new Admin();
ad.setVisible(true);
}
});
btnNewButton.setForeground(new Color(255, 240, 245));
btnNewButton.setBackground(new Color(0, 139, 139));
btnNewButton.setFont(new Font("Sitka Text", Font.BOLD, 30));

JButton btnNewButton_2 = new JButton("Customer");
btnNewButton_2.setBounds(32, 477, 214, 85);
panel.add(btnNewButton_2);
btnNewButton_2.addActionListener(new ActionListener() {

public void actionPerformed(ActionEvent e) {

Login log=new Login();
log.setVisible(true);

}
});
btnNewButton_2.setForeground(new Color(255, 240, 245));
btnNewButton_2.setBackground(new Color(0, 139, 139));
btnNewButton_2.setFont(new Font("Sitka Text", Font.BOLD, 30));

JLabel lblNewLabel_11 = new JLabel("New label");
lblNewLabel_11.setIcon(new ImageIcon("C:\\Users\\SRUSHTI JAMBHALE\\Downloads\\Screenshot 2024-04-13 012935.png"));
lblNewLabel_11.setBounds(-39, 24, 385, 209);
panel.add(lblNewLabel_11);

JLabel lblNewLabel_12 = new JLabel("MooTales");
lblNewLabel_12.setForeground(new Color(240, 248, 255));
lblNewLabel_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
lblNewLabel_12.setBounds(74, 234, 139, 39);
panel.add(lblNewLabel_12);

JLabel lblNewLabel_13 = new JLabel("Welcomes You...");
lblNewLabel_13.setFont(new Font("Tahoma", Font.ITALIC, 20));
lblNewLabel_13.setForeground(new Color(240, 255, 255));
lblNewLabel_13.setBounds(53, 283, 193, 19);
panel.add(lblNewLabel_13);

JLabel lblNewLabel_1 = new JLabel("Experience Pure Delite with MooTales Dairy Products");
lblNewLabel_1.setFont(new Font("Tahoma", Font.ITALIC, 23));
lblNewLabel_1.setBounds(339, 190, 558, 41);
contentPane.add(lblNewLabel_1);

JLabel lblNewLabel_2 = new JLabel("\"Farm-Fresh Dairy Deliveries\"");
lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
lblNewLabel_2.setBounds(442, 129, 233, 25);
contentPane.add(lblNewLabel_2);

JLabel lblNewLabel_3 = new JLabel("Welcome to Mootales: ");
lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
lblNewLabel_3.setBounds(339, 328, 213, 19);
contentPane.add(lblNewLabel_3);

JLabel lblNewLabel_4 = new JLabel("Where Every Drop Tells a Story");
lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 17));
lblNewLabel_4.setBounds(334, 344, 278, 32);
contentPane.add(lblNewLabel_4);

JLabel lblNewLabel_5 = new JLabel("Mootales traces its roots back to a ");
lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 16));
lblNewLabel_5.setBounds(339, 386, 250, 25);
contentPane.add(lblNewLabel_5);

JLabel lblNewLabel_6 = new JLabel("quaint family farm in countryside.");
lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 16));
lblNewLabel_6.setBounds(339, 416, 250, 19);
contentPane.add(lblNewLabel_6);

JLabel lblNewLabel_7 = new JLabel("Mootales has remained steadfast in its ");
lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 16));
lblNewLabel_7.setBounds(339, 445, 297, 19);
contentPane.add(lblNewLabel_7);

JLabel lblNewLabel_8 = new JLabel("commitment to excellence. ");
lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 16));
lblNewLabel_8.setBounds(339, 474, 250, 19);
contentPane.add(lblNewLabel_8);

JLabel lblNewLabel_9 = new JLabel("At Mootales, quality is more ");
lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 15));
lblNewLabel_9.setBounds(339, 503, 273, 19);
contentPane.add(lblNewLabel_9);

JLabel lblNewLabel_10 = new JLabel("than just a standard");
lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 15));
lblNewLabel_10.setBounds(339, 528, 213, 19);
contentPane.add(lblNewLabel_10);
}
}
