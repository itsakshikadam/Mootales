package dbms;



import java.awt.EventQueue;



import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;



import javax.swing.JOptionPane;



import java.awt.Font;

import javax.swing.SwingConstants;

import javax.swing.JTextArea;

import javax.swing.JPasswordField;

import javax.swing.JButton;

import java.awt.Color;

import java.awt.event.ActionListener;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.awt.event.ActionEvent;



public class Login extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;

	private JPasswordField passwordField;

	Connection connection;

	/**

	 * Launch the application.

	 */

	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {

			public void run() {

				try {

					Login frame = new Login();

					frame.setVisible(true);

				} catch (Exception e) {

					e.printStackTrace();

				}

			}

		});

	}



	/**

	 * Create the frame.

	 */

	public Login() {
		
		try {
            // Load the MySQL JDBC driver class
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
        } catch (ClassNotFoundException | SQLException e1) {
            e1.printStackTrace();
        }

		setResizable(false);

		setTitle("LOGIN Page");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 865, 643);

		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		contentPane.setLayout(null);

		

		JLabel lblNewLabel = new JLabel("LOGIN");

		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);

		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));

		lblNewLabel.setBounds(451, 63, 152, 64);

		contentPane.add(lblNewLabel);

		

		JLabel lblNewLabel_1 = new JLabel("USERID");

		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		lblNewLabel_1.setBounds(346, 164, 124, 25);

		contentPane.add(lblNewLabel_1);

		

		JLabel lblNewLabel_2 = new JLabel("PASSWORD");

		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		lblNewLabel_2.setBounds(346, 267, 137, 33);

		contentPane.add(lblNewLabel_2);

		

		final JTextArea textArea = new JTextArea();

		textArea.setBounds(346, 213, 434, 26);

		contentPane.add(textArea);

		

		passwordField = new JPasswordField();

		passwordField.setBounds(346, 309, 424, 30);

		contentPane.add(passwordField);

		

		JButton btnNewButton = new JButton("LOGIN");

		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// Validate input before parsing
                String uid = textArea.getText().trim();
                String pass = new String(passwordField.getPassword());

                if (uid.isEmpty() || pass.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both User ID and Password.");
                    return; // Exit the method without further processing
                }

		 int userid = Integer.parseInt(textArea.getText()); // Retrieving userid from JTextArea

			String password = new String(passwordField.getPassword()); // Retrieving password from JPasswordField

			try (PreparedStatement pstmt = connection.prepareStatement("SELECT * FROM customers WHERE Cust_ID = ? AND Password = ?")) {
			            pstmt.setInt(1, userid);
			            pstmt.setString(2, password);
			            ResultSet resultSet = pstmt.executeQuery();

			            if(resultSet.next()) {
			            JOptionPane.showMessageDialog(null, "Login successful");
			            new Admin().setVisible(true);
			            }
			            else {
			            JOptionPane.showMessageDialog(null, "Username or password wrong..."); // Display failure message
			            textArea.setText("");
			            passwordField.setText("");
			            }
			        } catch (SQLException e1) {
			            e1.printStackTrace();
			        }
			
			CustomerPage cs = new CustomerPage();
            cs.setVisible(true);
			}

			});

		btnNewButton.setForeground(new Color(248, 248, 255));

		btnNewButton.setBackground(new Color(0, 128, 128));

		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 25));

		btnNewButton.setBounds(346, 385, 152, 39);

		contentPane.add(btnNewButton);

		

		JPanel panel = new JPanel();

		panel.setBackground(new Color(0, 128, 128));

		panel.setBounds(10, 10, 306, 586);

		contentPane.add(panel);

		panel.setLayout(null);

		

		JLabel lblNewLabel_3 = new JLabel("WELCOME");

		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 30));

		lblNewLabel_3.setBounds(57, 209, 189, 100);

		panel.add(lblNewLabel_3);

		
		JButton btnNewButton_2 = new JButton("Back");

		btnNewButton_2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				project pr=new project();

				pr.setVisible(true);

			}

		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 15));

		btnNewButton_2.setBounds(10, 10, 76, 21);

		panel.add(btnNewButton_2);
		
		
		JLabel lblNewLabel_4 = new JLabel("I don't have an account");

		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 15));

		lblNewLabel_4.setBounds(346, 477, 178, 19);

		contentPane.add(lblNewLabel_4);

		

		JButton btnNewButton_1 = new JButton("Sign Up");

		btnNewButton_1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				Signup sg=new Signup();

				sg.setVisible(true);

			}

		});

		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));

		btnNewButton_1.setBounds(553, 470, 131, 33);

		contentPane.add(btnNewButton_1);

	}

}

