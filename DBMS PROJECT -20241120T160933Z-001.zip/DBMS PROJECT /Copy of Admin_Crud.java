package dbms;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Admin_Crud extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    Connection connection;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Admin_Crud frame = new Admin_Crud();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Admin_Crud() {
		setResizable(false);

		setTitle("AdminPAge");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 873, 656);

		contentPane = new JPanel();

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		contentPane.setLayout(null);

		

		
		

		JLabel lblNewLabel = new JLabel("Product ID");

		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel.setBounds(37, 125, 85, 29);

		contentPane.add(lblNewLabel);

		

		JTextArea textArea = new JTextArea();

		textArea.setBounds(165, 129, 111, 22);

		contentPane.add(textArea);

		

		JLabel lblNewLabel_1 = new JLabel("Product Name");

		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel_1.setBounds(35, 181, 108, 21);

		contentPane.add(lblNewLabel_1);

		

		JTextArea textArea_1 = new JTextArea();

		textArea_1.setBounds(165, 181, 111, 22);

		contentPane.add(textArea_1);

		

		JLabel lblNewLabel_2 = new JLabel("Price");

		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel_2.setBounds(37, 224, 72, 33);

		contentPane.add(lblNewLabel_2);

		

		JTextArea textArea_2 = new JTextArea();

		textArea_2.setBounds(165, 230, 111, 22);

		contentPane.add(textArea_2);

		

		JLabel lblNewLabel_3 = new JLabel("Quantity");

		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel_3.setBounds(35, 275, 85, 29);

		contentPane.add(lblNewLabel_3);

		

		JTextArea textArea_3 = new JTextArea();

		textArea_3.setBounds(165, 279, 111, 22);

		contentPane.add(textArea_3);

		

		JLabel lblNewLabel_4 = new JLabel("Expiry Date");

		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel_4.setBounds(37, 331, 101, 22);

		contentPane.add(lblNewLabel_4);

		

		JTextArea textArea_4 = new JTextArea();

		textArea_4.setBounds(165, 332, 111, 22);

		contentPane.add(textArea_4);

		

		JLabel lblNewLabel_5 = new JLabel("Stock Available ");

		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 20));

		lblNewLabel_5.setBounds(520, 43, 201, 29);

		contentPane.add(lblNewLabel_5);

		

		JButton btnNewButton_4 = new JButton("Log Out");

		btnNewButton_4.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				Admin ad = new Admin();

				ad.setVisible(true);

			}

		});

		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));

		btnNewButton_4.setBounds(79, 535, 145, 47);

		contentPane.add(btnNewButton_4);

		

		JLabel lblNewLabel_6 = new JLabel("Admin ID");

		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 15));

		lblNewLabel_6.setBounds(37, 87, 85, 13);

		contentPane.add(lblNewLabel_6);

		

		JTextArea textArea_5 = new JTextArea();

		textArea_5.setBounds(165, 83, 111, 22);

		contentPane.add(textArea_5);

		

		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setBounds(343, 90, 506, 469);

		contentPane.add(scrollPane);

		JButton btnNewButton = new JButton("INSERT");

		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		btnNewButton.setBounds(24, 397, 119, 33);
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the connection to the database
                    Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");

                    // Prepare the SQL statement to insert a new product
                    String query = "INSERT INTO Product(ProductID, ProductName, Price, QuantityAvailable, ExpiryDate) VALUES ( ?, ?, ?, ?, ?)";
                    PreparedStatement ps = conn.prepareStatement(query);

                    // Set the values for the prepared statement
                    ps.setInt(1, Integer.parseInt(textArea.getText()));
                    ps.setString(2, textArea_1.getText());
                    ps.setDouble(3, Double.parseDouble(textArea_2.getText()));
                    ps.setInt(4, Integer.parseInt(textArea_3.getText()));
                    ps.setDate(5, Date.valueOf(textArea_4.getText()));
                    
                    // Execute the query
                   

                    int rowsAffected = ps.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Data Inserted Successfully !!");
                    } else {
                        JOptionPane.showMessageDialog(null, " Data not inserted.");
                    }

                 // Clear all text fields
    		        textArea.setText("");
    		        textArea_1.setText("");
    		        textArea_2.setText("");
    		        textArea_3.setText("");
    		        textArea_4.setText("");
    		        textArea_5.setText("");
                    
                    // Reload the data in the table
                    displayProductTable();

                } catch (Exception ex) {
                    // Show an error message if there's an exception
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        });
		contentPane.add(btnNewButton);

		

		JButton btnNewButton_1 = new JButton("UPDATE");

		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		btnNewButton_1.setBounds(165, 397, 126, 33);
		btnNewButton_1.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Get the connection to the database
		            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");
		            // Prepare the SQL statement to update a product
		            String query = "UPDATE Product SET ProductName=?, Price=?, QuantityAvailable=?, ExpiryDate=? WHERE ProductID=?";
		            PreparedStatement ps = conn.prepareStatement(query);
		         // Set the value for the prepared statement
		            ps.setInt(1, Integer.parseInt(textArea.getText()));
		            
		            // Set the values for the prepared statement
		            ps.setInt(1, Integer.parseInt(textArea.getText()));
                    ps.setString(2, textArea_1.getText());
                    ps.setDouble(3, Double.parseDouble(textArea_2.getText()));
                    ps.setInt(4, Integer.parseInt(textArea_3.getText()));
                    ps.setDate(5, Date.valueOf(textArea_4.getText()));
                    
		            // Execute the query
                    int rowsAffected = ps.executeUpdate();

		         // Clear all text fields
    		        textArea.setText("");
    		        textArea_1.setText("");
    		        textArea_2.setText("");
    		        textArea_3.setText("");
    		        textArea_4.setText("");
    		        textArea_5.setText("");

    		        

    		        if (rowsAffected > 0) {
    		            JOptionPane.showMessageDialog(null, "Data Updated Successfully !!");
    		        } else {
    		            JOptionPane.showMessageDialog(null, " Data not updated.");
    		        }

		            // Reload the data in the table
		            displayProductTable();

		        } catch (Exception ex) {
		            // Show an error message if there's an exception
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		            ex.printStackTrace();
		        }} });

		contentPane.add(btnNewButton_1);

		

		JButton btnNewButton_2 = new JButton("DELETE");

		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		btnNewButton_2.setBounds(24, 464, 119, 33);
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Get the connection to the database
		           connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbms", "root", "root26");

		            // Prepare the SQL statement to delete a product
		            String query = "DELETE FROM Product WHERE ProductID=?";
		            PreparedStatement ps = connection.prepareStatement(query);

		            // Set the value for the prepared statement
		            ps.setInt(1, Integer.parseInt(textArea.getText()));

		            // Execute the query
		            int rowsAffected = ps.executeUpdate();

		            /// Clear all text fields
    		        textArea.setText("");
    		        textArea_1.setText("");
    		        textArea_2.setText("");
    		        textArea_3.setText("");
    		        textArea_4.setText("");
    		        textArea_5.setText("");
    		        
    		       

    		        if (rowsAffected > 0) {
    		            JOptionPane.showMessageDialog(null, "Data Deleted Successfully !!");
    		        } else {
    		            JOptionPane.showMessageDialog(null, " Data not deleted.");
    		        }

		            // Reload the data in the table
		            displayProductTable();

		        } catch (Exception ex) {
		            // Show an error message if there's an exception
		            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
		            ex.printStackTrace();
		        }
		    }
		});

		contentPane.add(btnNewButton_2);

		

		JButton btnNewButton_3 = new JButton("CLEAR");

		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));

		btnNewButton_3.setBounds(176, 464, 115, 33);
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Clear all text fields
		        textArea.setText("");
		        textArea_1.setText("");
		        textArea_2.setText("");
		        textArea_3.setText("");
		        textArea_4.setText("");
		        textArea_5.setText("");
		    }
		});

		contentPane.add(btnNewButton_3);


		table = new JTable();

		scrollPane.setViewportView(table);

		

		JPanel panel = new JPanel();

		panel.setBackground(new Color(0, 128, 128));

		panel.setBounds(0, 0, 333, 619);

		contentPane.add(panel);

		panel.setLayout(null);

		

		

		

		JButton btnNewButton_6 = new JButton("Check");

		btnNewButton_6.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				displayProductTable();

			}

		});

		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));

		btnNewButton_6.setBounds(449, 579, 93, 31);

		contentPane.add(btnNewButton_6);

	}

    // Method to display the Product table
    private void displayProductTable() {
        String url = "jdbc:mysql://localhost:3306/dbms";
        String user = "root";
        String password = "root26";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Product");
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            DefaultTableModel model = new DefaultTableModel();

            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            while (resultSet.next()) {
                Object[] row = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = resultSet.getObject(i);
                }
                model.addRow(row);
            }

            table.setModel(model);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
		}
    

